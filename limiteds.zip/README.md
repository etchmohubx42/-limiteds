# /limiteds Website

Premium storefront for lvory.gge — Da Hood Cheat.

## Structure

```
limiteds-website/
├── index.html          # Main page (all sections)
├── styles.css          # Complete stylesheet
├── script.js           # All JavaScript functionality
├── .env.example        # Environment variables template
├── assets/             # All image assets
│   ├── 1000043944.png  # Roblox character (hero)
│   ├── 1000043945.jpg  # MM2 knife
│   ├── 1000043941.png  # Limited items collection
│   ├── 1000043975.jpg  # Headless item
│   ├── 1000043973.jpg  # Face/Headless
│   ├── 1000043934.png  # Character with horns
│   ├── 1000043933.png  # Pumpkin headless character
│   ├── 1000043924.jpg  # TikTok logo
│   ├── 1000043923.jpg  # Instagram logo
│   ├── 1000043734.png  # Gold Robux
│   └── 1000043739.png  # Pink gem
```

## Features

- Multi-layer atmospheric background with floating limited items
- Sticky glassmorphism navigation
- Hero section with prominent branding
- Discord CTA section
- Product feature cards (editable placeholders)
- Premium pricing card with glow effects
- Visual payment method cards
- PIX payment card
- How to Buy section with copy-to-clipboard
- FAQ accordion
- Disclaimer/Terms section
- AI Assistant chat widget (frontend-only, ready for backend)
- Fully responsive (mobile, tablet, desktop)
- Scroll reveal animations
- Parallax effects
- All text in English

## AI Integration

The AI Assistant currently runs entirely in the browser with a predefined knowledge base. To connect a real AI API:

1. Copy `.env.example` to `.env`
2. Add your AI API key
3. Create a backend endpoint that proxies requests to the AI API
4. Update `script.js` to call your backend instead of using the local knowledge base

**Never expose API keys in frontend code.**

## Hosting

This is a static website. Upload all files to any static hosting provider:
- Vercel
- Netlify
- GitHub Pages
- Cloudflare Pages
- Any web server

## Editing

### Add more games:
Edit the "More games coming soon" text in the Cheat section of `index.html`.

### Add more payment methods:
Add new `.payment-card` elements in the Payments section of `index.html`.

### Add more products:
Duplicate the `.pricing-card` in the Pricing section of `index.html`.

### Change prices:
Edit the `.price-brl` and `.price-robux` elements in `index.html`.

### Change Discord link:
Replace `https://discord.gg/arPcA3sCc` throughout `index.html`.

### Change contact:
Replace `@infecions` throughout `index.html` and `script.js`.

## Credits

/limiteds — lvory.gge
