/* ============================================
   /limiteds — ULTRA PREMIUM JAVASCRIPT
   Particles, Animations, Interactions
   ============================================ */

(function() {
    'use strict';

    const limitedImages = [
        'assets/1000043944.png', 'assets/1000043945.jpg', 'assets/1000043941.png',
        'assets/1000043975.jpg', 'assets/1000043973.jpg', 'assets/1000043934.png',
        'assets/1000043933.png', 'assets/1000043924.jpg', 'assets/1000043923.jpg',
        'assets/1000043734.png', 'assets/1000043739.png'
    ];

    /* ============================================
       CANVAS PARTICLE SYSTEM
       ============================================ */

    function initCanvasParticles() {
        const canvas = document.getElementById('particleCanvas');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        let particles = [];
        let mouseX = 0, mouseY = 0;
        let isMobile = window.innerWidth < 768;
        let animationId;

        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            isMobile = window.innerWidth < 768;
        }

        resize();
        window.addEventListener('resize', resize);

        class Particle {
            constructor() {
                this.reset();
            }

            reset() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 2 + 0.5;
                this.speedX = (Math.random() - 0.5) * 0.4;
                this.speedY = (Math.random() - 0.5) * 0.4;
                this.opacity = Math.random() * 0.5 + 0.1;
                this.glow = Math.random() * 15 + 5;
                this.hue = Math.random() > 0.7 ? 45 : Math.random() > 0.5 ? 260 : 0;
            }

            update() {
                this.x += this.speedX;
                this.y += this.speedY;

                // Mouse interaction (desktop only)
                if (!isMobile) {
                    const dx = mouseX - this.x;
                    const dy = mouseY - this.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 150) {
                        const force = (150 - dist) / 150;
                        this.x -= dx * force * 0.02;
                        this.y -= dy * force * 0.02;
                    }
                }

                if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
                    this.reset();
                }
            }

            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                if (this.hue === 45) {
                    ctx.fillStyle = `rgba(212, 175, 55, ${this.opacity})`;
                    ctx.shadowColor = 'rgba(212, 175, 55, 0.5)';
                } else if (this.hue === 260) {
                    ctx.fillStyle = `rgba(140, 120, 200, ${this.opacity})`;
                    ctx.shadowColor = 'rgba(140, 120, 200, 0.4)';
                } else {
                    ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity * 0.5})`;
                    ctx.shadowColor = 'rgba(255, 255, 255, 0.3)';
                }
                ctx.shadowBlur = this.glow;
                ctx.fill();
                ctx.shadowBlur = 0;
            }
        }

        // Create particles
        const particleCount = isMobile ? 30 : 80;
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }

        // Draw connections between nearby particles
        function drawConnections() {
            const maxDist = isMobile ? 80 : 120;
            const maxConnections = 3;

            for (let i = 0; i < particles.length; i++) {
                let connections = 0;
                for (let j = i + 1; j < particles.length; j++) {
                    const dx = particles[i].x - particles[j].x;
                    const dy = particles[i].y - particles[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);

                    if (dist < maxDist && connections < maxConnections) {
                        const opacity = (1 - dist / maxDist) * 0.08;
                        ctx.beginPath();
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.strokeStyle = `rgba(212, 175, 55, ${opacity})`;
                        ctx.lineWidth = 0.5;
                        ctx.stroke();
                        connections++;
                    }
                }
            }
        }

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            particles.forEach(p => {
                p.update();
                p.draw();
            });

            if (!isMobile) {
                drawConnections();
            }

            animationId = requestAnimationFrame(animate);
        }

        animate();

        // Mouse tracking
        document.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
        });

        // Pause when tab hidden
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                cancelAnimationFrame(animationId);
            } else {
                animate();
            }
        });
    }

    /* ============================================
       BACKGROUND LIMITEDS
       ============================================ */

    function createBackgroundLimiteds() {
        const isMobile = window.innerWidth < 768;

        if (!isMobile) {
            const layer2 = document.getElementById('bgLayer2');
            for (let i = 0; i < 6; i++) {
                const item = document.createElement('img');
                item.src = limitedImages[i % limitedImages.length];
                item.className = 'bg-item';
                item.alt = '';
                item.setAttribute('aria-hidden', 'true');
                item.loading = 'lazy';
                const size = 200 + Math.random() * 300;
                item.style.width = size + 'px';
                item.style.left = (Math.random() * 100) + '%';
                item.style.top = (Math.random() * 100) + '%';
                item.style.transform = `rotate(${Math.random() * 360}deg)`;
                item.style.animationDelay = (Math.random() * 10) + 's';
                item.style.animationDuration = (18 + Math.random() * 8) + 's';
                layer2.appendChild(item);
            }
        }

        const layer3 = document.getElementById('bgLayer3');
        const count3 = isMobile ? 3 : 8;
        for (let i = 0; i < count3; i++) {
            const item = document.createElement('img');
            item.src = limitedImages[(i + 3) % limitedImages.length];
            item.className = 'bg-item';
            item.alt = '';
            item.setAttribute('aria-hidden', 'true');
            item.loading = 'lazy';
            const size = 100 + Math.random() * 150;
            item.style.width = size + 'px';
            item.style.left = (Math.random() * 100) + '%';
            item.style.top = (Math.random() * 100) + '%';
            item.style.transform = `rotate(${Math.random() * 360}deg)`;
            item.style.animationDelay = (Math.random() * 8) + 's';
            item.style.animationDuration = (12 + Math.random() * 6) + 's';
            layer3.appendChild(item);
        }

        const layer4 = document.getElementById('bgLayer4');
        const count4 = isMobile ? 2 : 5;
        for (let i = 0; i < count4; i++) {
            const item = document.createElement('img');
            item.src = limitedImages[(i + 6) % limitedImages.length];
            item.className = 'bg-item';
            item.alt = '';
            item.setAttribute('aria-hidden', 'true');
            item.loading = 'lazy';
            const size = 60 + Math.random() * 80;
            item.style.width = size + 'px';
            item.style.left = (Math.random() * 100) + '%';
            item.style.top = (Math.random() * 100) + '%';
            item.style.transform = `rotate(${Math.random() * 360}deg)`;
            item.style.animationDelay = (Math.random() * 6) + 's';
            item.style.animationDuration = (8 + Math.random() * 4) + 's';
            layer4.appendChild(item);
        }

        if (!isMobile) {
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = (Math.random() * 100) + '%';
                particle.style.animationDelay = (Math.random() * 8) + 's';
                particle.style.animationDuration = (6 + Math.random() * 6) + 's';
                layer4.appendChild(particle);
            }
        }
    }

    function createFooterBackground() {
        const footerBg = document.getElementById('footerBg');
        if (!footerBg) return;
        for (let i = 0; i < 4; i++) {
            const item = document.createElement('img');
            item.src = limitedImages[i % limitedImages.length];
            item.className = 'bg-item';
            item.alt = '';
            item.setAttribute('aria-hidden', 'true');
            item.loading = 'lazy';
            const size = 150 + Math.random() * 200;
            item.style.width = size + 'px';
            item.style.left = (10 + Math.random() * 80) + '%';
            item.style.top = (10 + Math.random() * 80) + '%';
            item.style.transform = `rotate(${Math.random() * 360}deg)`;
            footerBg.appendChild(item);
        }
    }

    /* ============================================
       NAVBAR
       ============================================ */

    function initNavbar() {
        const navbar = document.getElementById('navbar');
        function updateNavbar() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }
        window.addEventListener('scroll', updateNavbar, { passive: true });
        updateNavbar();
    }

    function initMobileNav() {
        const toggle = document.getElementById('navToggle');
        const links = document.getElementById('navLinks');
        if (!toggle || !links) return;

        toggle.addEventListener('click', () => {
            links.classList.toggle('open');
            toggle.classList.toggle('open');
            toggle.setAttribute('aria-expanded', links.classList.contains('open'));
        });

        links.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                links.classList.remove('open');
                toggle.classList.remove('open');
                toggle.setAttribute('aria-expanded', 'false');
            });
        });

        document.addEventListener('click', (e) => {
            if (!toggle.contains(e.target) && !links.contains(e.target)) {
                links.classList.remove('open');
                toggle.classList.remove('open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    /* ============================================
       FAQ
       ============================================ */

    function initFAQ() {
        const items = document.querySelectorAll('.faq-item');
        items.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                items.forEach(other => {
                    other.classList.remove('active');
                    other.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
                });
                if (!isActive) {
                    item.classList.add('active');
                    question.setAttribute('aria-expanded', 'true');
                }
            });
        });
    }

    /* ============================================
       COPY USERNAME
       ============================================ */

    function initCopyUsername() {
        const btn = document.getElementById('copyUsername');
        const feedback = document.getElementById('copyFeedback');
        if (!btn || !feedback) return;

        btn.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText('@infecions');
                feedback.classList.add('show');
                setTimeout(() => feedback.classList.remove('show'), 2000);
            } catch (err) {
                const textarea = document.createElement('textarea');
                textarea.value = '@infecions';
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                feedback.classList.add('show');
                setTimeout(() => feedback.classList.remove('show'), 2000);
            }
        });
    }

    /* ============================================
       AI ASSISTANT
       ============================================ */

    function initAIAssistant() {
        const widget = document.getElementById('aiWidget');
        const trigger = document.getElementById('aiTrigger');
        const panel = document.getElementById('aiPanel');
        const closeBtn = document.getElementById('aiClose');
        const input = document.getElementById('aiInput');
        const sendBtn = document.getElementById('aiSend');
        const messagesContainer = document.getElementById('aiMessages');

        if (!widget || !trigger || !panel) return;

        trigger.addEventListener('click', () => {
            panel.classList.toggle('open');
            if (panel.classList.contains('open')) input.focus();
        });

        closeBtn.addEventListener('click', () => panel.classList.remove('open'));

        const knowledge = {
            'what is lvory.gge': 'lvory.gge is a premium cheat/script for the Roblox game Da Hood. More games will be supported in the future.',
            'what is ivory.gge': 'lvory.gge is a premium cheat/script for the Roblox game Da Hood. More games will be supported in the future.',
            'how much': 'The lvory.gge script costs 40 BRL or 7K Robux (via Plus). Higher prices mean a better cheat.',
            'price': 'The lvory.gge script costs 40 BRL or 7K Robux (via Plus). Higher prices mean a better cheat.',
            'cost': 'The lvory.gge script costs 40 BRL or 7K Robux (via Plus). Higher prices mean a better cheat.',
            'payment': 'We accept: 3x Discord Boost, Robux, TikTok/Instagram accounts (8K+ followers), good eBoy Roblox accounts, MM2 best sets, Headless or Korblox accounts, Headless + Korblox accounts, tuff limiteds or accounts with limiteds, and PIX.',
            'pay': 'We accept: 3x Discord Boost, Robux, TikTok/Instagram accounts (8K+ followers), good eBoy Roblox accounts, MM2 best sets, Headless or Korblox accounts, Headless + Korblox accounts, tuff limiteds or accounts with limiteds, and PIX.',
            'how to buy': 'You can purchase by joining our Discord server and creating a ticket, or by messaging @infecions directly on Discord.',
            'purchase': 'You can purchase by joining our Discord server and creating a ticket, or by messaging @infecions directly on Discord.',
            'buy': 'You can purchase by joining our Discord server and creating a ticket, or by messaging @infecions directly on Discord.',
            'discord': 'Our Discord server is at discord.gg/arPcA3sCc. Join to purchase, get support, open tickets, and receive updates.',
            'support': 'Join our Discord server at discord.gg/arPcA3sCc to open a support ticket or message @infecions directly.',
            'ticket': 'Join our Discord server at discord.gg/arPcA3sCc and create a ticket if the bot is online.',
            'contact': 'You can contact @infecions on Discord directly, or join our server at discord.gg/arPcA3sCc.',
            'infecions': '@infecions is our contact on Discord. Message them to purchase the cheat and specify your payment method.',
            'website buy': 'Currently, all purchases are processed manually through Discord. The website checkout redirects you to our Discord server.',
            'checkout': 'Currently, all purchases are processed manually through Discord. The website checkout redirects you to our Discord server.',
            'refund': 'All sales are final, no refunds. No whitelist transfers or re-whitelisting.',
            'games': 'Currently supported: Da Hood. More games coming soon.',
            'da hood': 'lvory.gge is a premium cheat for Da Hood on Roblox.',
            'roblox': 'lvory.gge is a Roblox script/cheat for Da Hood.',
            'hello': 'Hello! I am the /limiteds AI Assistant. How can I help you today?',
            'hi': 'Hello! I am the /limiteds AI Assistant. How can I help you today?',
            'hey': 'Hello! I am the /limiteds AI Assistant. How can I help you today?'
        };

        function getResponse(query) {
            const q = query.toLowerCase().trim();
            if (knowledge[q]) return knowledge[q];
            for (const [key, value] of Object.entries(knowledge)) {
                if (q.includes(key) || key.includes(q)) return value;
            }
            return "I don't have specific information about that. Please join our Discord server at discord.gg/arPcA3sCc or message @infecions for assistance.";
        }

        function addMessage(text, isUser) {
            const msg = document.createElement('div');
            msg.className = 'ai-message ' + (isUser ? 'ai-user' : 'ai-bot');
            msg.innerHTML = '<p>' + escapeHtml(text) + '</p>';
            messagesContainer.appendChild(msg);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function handleSend() {
            const text = input.value.trim();
            if (!text) return;
            addMessage(text, true);
            input.value = '';
            setTimeout(() => {
                const response = getResponse(text);
                addMessage(response, false);
            }, 600);
        }

        sendBtn.addEventListener('click', handleSend);
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleSend();
        });
    }

    /* ============================================
       SCROLL REVEAL
       ============================================ */

    function initScrollReveal() {
        const observerOptions = { root: null, rootMargin: '0px', threshold: 0.1 };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        document.querySelectorAll('.section-header, .feature-card, .payment-card, .howtobuy-card, .faq-item, .pricing-card, .discord-card, .disclaimer-card, .pix-card, .section-divider').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(24px)';
            el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
            observer.observe(el);
        });
    }

    /* ============================================
       SMOOTH SCROLL
       ============================================ */

    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                const target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    const offset = 80;
                    const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
                    window.scrollTo({ top: targetPosition, behavior: 'smooth' });
                }
            });
        });
    }

    /* ============================================
       PARALLAX
       ============================================ */

    function initParallax() {
        if (window.innerWidth < 1024) return;
        const heroImage = document.querySelector('.hero-image');
        if (!heroImage) return;
        let ticking = false;
        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(() => {
                    const scrollY = window.scrollY;
                    heroImage.style.transform = `translateY(${scrollY * 0.15}px)`;
                    ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });
    }

    /* ============================================
       MAGNETIC BUTTON EFFECT
       ============================================ */

    function initMagneticButtons() {
        if (window.innerWidth < 1024) return;
        document.querySelectorAll('.btn-primary, .btn-discord, .btn-pricing').forEach(btn => {
            btn.addEventListener('mousemove', (e) => {
                const rect = btn.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                btn.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
            });
            btn.addEventListener('mouseleave', () => {
                btn.style.transform = '';
            });
        });
    }

    /* ============================================
       TILT EFFECT ON CARDS
       ============================================ */

    function initTiltEffect() {
        if (window.innerWidth < 1024) return;
        document.querySelectorAll('.pricing-card, .discord-card, .howtobuy-card').forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width;
                const y = (e.clientY - rect.top) / rect.height;
                const tiltX = (y - 0.5) * 8;
                const tiltY = (x - 0.5) * -8;
                card.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) translateY(-10px)`;
            });
            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });
    }

    /* ============================================
       INITIALIZE
       ============================================ */

    function init() {
        initCanvasParticles();
        createBackgroundLimiteds();
        createFooterBackground();
        initNavbar();
        initMobileNav();
        initFAQ();
        initCopyUsername();
        initAIAssistant();
        initScrollReveal();
        initSmoothScroll();
        initParallax();
        initMagneticButtons();
        initTiltEffect();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
